package config

import (
	"log"
	"os"

	"github.com/joho/godotenv"
)

// Структура конфигурации приложения
type Config struct {
	AppEnv      string
	DBURL       string
	RedisAddr   string
	KafkaBroker string
	KafkaTopic  string
}

// Загрузка конфигурации из .env
func Load() *Config {
	_ = godotenv.Load() // Подгружаем .env в окружение

	cfg := &Config{
		AppEnv:      os.Getenv("APP_ENV"),
		DBURL:       os.Getenv("DB_URL"),
		RedisAddr:   os.Getenv("REDIS_ADDR"),
		KafkaBroker: os.Getenv("KAFKA_BROKER"),
		KafkaTopic:  os.Getenv("KAFKA_TOPIC"),
	}

	if cfg.DBURL == "" {
		log.Fatal("DB_URL не задан")
	}

	return cfg
}
