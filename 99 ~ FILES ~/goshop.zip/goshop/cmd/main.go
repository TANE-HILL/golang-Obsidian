package main

import (
	"goshop/internal/cache"
	"goshop/internal/config"
	"goshop/internal/db"
	"goshop/internal/events"
	"goshop/internal/handlers"
	"goshop/internal/services"
	"log"
	"net/http"
)

func main() {
	cfg := config.Load()
	dbConn, err := db.NewPostgres(cfg.DBURL)
	if err != nil {
		log.Fatal(err)
	}
	redisCache := cache.NewProductCache(cfg.RedisAddr)
	publisher := events.NewPublisher(cfg.KafkaBroker, cfg.KafkaTopic)

	// Репозитории и сервисы
	productRepo := db.NewProductRepo(dbConn)
	orderRepo := db.NewOrderRepo(dbConn)

	productService := services.NewProductService(productRepo, redisCache)
	orderService := services.NewOrderService(orderRepo, publisher)

	productHandler := handlers.NewProductHandler(productService)
	orderHandler := handlers.NewOrderHandler(orderService)

	http.HandleFunc("/products/", productHandler.GetProduct)
	http.HandleFunc("/orders", orderHandler.CreateOrder)

	log.Println("🚀 Server started on :8080")
	http.ListenAndServe(":8080", nil)
}
