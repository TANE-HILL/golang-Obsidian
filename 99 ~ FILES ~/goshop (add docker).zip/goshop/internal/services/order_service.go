package services

import (
	"context"
	"goshop/internal/db"
	"goshop/internal/events"
	"goshop/internal/models"
)

type OrderService struct {
	repo      *db.OrderRepo
	publisher *events.Publisher
}

func NewOrderService(repo *db.OrderRepo, publisher *events.Publisher) *OrderService {
	return &OrderService{repo: repo, publisher: publisher}
}

func (s *OrderService) CreateOrder(ctx context.Context, o *models.Order) error {
	createdOrder, err := s.repo.Create(ctx, o)
	if err != nil {
		return err
	}
	return s.publisher.PublishOrderCreated(ctx, createdOrder.ID)
}

func (s *OrderService) GetOrder(ctx context.Context, id int) (*models.Order, error) {
	return s.repo.GetByID(ctx, id)
}
