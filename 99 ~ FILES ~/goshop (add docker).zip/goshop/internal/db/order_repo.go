package db

import (
	"context"
	"goshop/internal/models"

	"github.com/jmoiron/sqlx"
)

type OrderRepo struct {
	db DBTX
}

func NewOrderRepo(db *sqlx.DB) *OrderRepo {
	return &OrderRepo{db: db}
}

func (r *OrderRepo) Create(ctx context.Context, o *models.Order) (models.Order, error) {
	var ord models.Order

	query := `
 INSERT INTO orders (product_id, quantity, total)
 VALUES ($1, $2, $3)
 RETURNING id, product_id, quantity, total;
 `

	if err := r.db.GetContext(ctx, &ord, query,
		o.ProductID, o.Quantity, o.Total); err != nil {
		return models.Order{}, err
	}
	return ord, nil
}

func (r *OrderRepo) GetByID(ctx context.Context, id int) (*models.Order, error) {
	var order models.Order

	err := r.db.GetContext(
		ctx,
		&order,
		"SELECT * FROM orders WHERE id = $1",
		id,
	)
	if err != nil {
		return nil, err
	}

	return &order, nil
}
