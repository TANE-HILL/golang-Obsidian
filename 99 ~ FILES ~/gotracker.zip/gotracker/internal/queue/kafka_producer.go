package queue

import (
	"context"
	"encoding/json"
	"fmt"
	"gotracker/internal/order"
	"os"
	"time"

	"github.com/segmentio/kafka-go"
)

func SendOrderCreated(o order.Order) error {
	broker := os.Getenv("KAFKA_BROKER")
	writer := kafka.NewWriter(kafka.WriterConfig{
		Brokers:  []string{broker},
		Topic:    "orders",
		Balancer: &kafka.LeastBytes{},
	})
	defer writer.Close()

	data, err := json.Marshal(o)
	if err != nil {
		return err
	}

	msg := kafka.Message{
		Key:   []byte(fmt.Sprint(o.ID)),
		Value: data,
		Time:  time.Now(),
	}

	return writer.WriteMessages(context.Background(), msg)
}
