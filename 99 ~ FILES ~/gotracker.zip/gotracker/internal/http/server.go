package http

import (
	"database/sql"
	"encoding/json"
	"gotracker/internal/cache"
	"gotracker/internal/order"
	"gotracker/internal/service"
	"net/http"
	"strconv"
	"strings"
)

type Handler struct {
	service *service.OrderService
	db      *sql.DB
	cache   *cache.RedisCache
}

func NewHandler(service *service.OrderService, db *sql.DB, cache *cache.RedisCache) *Handler {
	return &Handler{service: service, db: db, cache: cache}
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path == "/" && r.Method == http.MethodGet {
		w.Write([]byte("Добро пожаловать в GoTracker API"))
		return
	}
	path := r.URL.Path
	method := r.Method

	if path == "/orders" && method == http.MethodGet {
		h.handleGetAll(w, r)
		return
	}

	if path == "/health" && method == http.MethodGet {
		h.handleHealth(w, r)
		return
	}

	if path == "/orders" && method == http.MethodPost {
		h.handleCreate(w, r)
		return
	}

	if strings.HasPrefix(path, "/orders/") && method == http.MethodPut {
		h.handleUpdate(w, r)
		return
	}

	http.NotFound(w, r)
}

func (h *Handler) handleGetAll(w http.ResponseWriter, r *http.Request) {
	orders := h.service.GetAll()
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(orders)
}

func (h *Handler) handleCreate(w http.ResponseWriter, r *http.Request) {
	var o order.Order
	if err := json.NewDecoder(r.Body).Decode(&o); err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}
	if o.ID <= 0 || o.Customer == "" || o.Address == "" {
		http.Error(w, "Missing or invalid fields", http.StatusBadRequest)
		return
	}
	if err := h.service.AddOrder(o); err != nil {
		http.Error(w, "Internal server error", http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusCreated)
}

func (h *Handler) handleHealth(w http.ResponseWriter, r *http.Request) {
	if err := h.db.Ping(); err != nil {
		http.Error(w, "DataBase Unavailable", http.StatusServiceUnavailable)
		return
	}
	if err := h.cache.Ping(); err != nil {
		http.Error(w, "Cache Unavailable", http.StatusServiceUnavailable)
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("OK"))
}

func (h *Handler) handleUpdate(w http.ResponseWriter, r *http.Request) {
	parts := strings.Split(r.URL.Path, "/")
	if len(parts) != 3 {
		http.Error(w, "Invalid URL", http.StatusBadRequest)
		return
	}
	id, err := strconv.Atoi(parts[2])
	if err != nil || id <= 0 {
		http.Error(w, "Invalid ID", http.StatusBadRequest)
		return
	}

	var o order.Order
	if err := json.NewDecoder(r.Body).Decode(&o); err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}
	o.ID = id

	if err := h.service.UpdateOrder(o); err != nil {
		http.Error(w, err.Error(), http.StatusNotFound)
		return
	}
	w.WriteHeader(http.StatusOK)
}
