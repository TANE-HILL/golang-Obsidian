package service

import (
	"fmt"
	"gotracker/internal/cache"
	"gotracker/internal/order"
	"gotracker/internal/queue"
	"gotracker/internal/repository"
)

type OrderService struct {
	repo  repository.Repository
	cache *cache.RedisCache
}

func NewOrderService(repo repository.Repository, cache *cache.RedisCache) *OrderService {
	return &OrderService{
		repo:  repo,
		cache: cache,
	}
}

func (s *OrderService) AddOrder(o order.Order) error {
	err := s.repo.Add(o)
	if err != nil {
		return err
	}
	_ = s.cache.Delete(o.ID)      // очищаем кэш
	_ = queue.SendOrderCreated(o) // отправляем сообщение в Kafka
	return nil
}

func (s *OrderService) GetAll() []order.Order {
	return s.repo.GetAll()
}

func (s *OrderService) GetByID(id int) (order.Order, error) {
	// сначала пробуем получить из кэша
	if s.cache != nil {
		if o, err := s.cache.Get(id); err == nil {
			fmt.Println("[Cache] Найден заказ в Redis")
			return o, nil
		}
	}

	// если не нашли — берём из репозитория и кладём в кэш
	o, err := s.repo.GetByID(id)
	if err != nil {
		return o, err
	}

	if s.cache != nil {
		_ = s.cache.Set(o)
	}
	return o, nil
}

func (s *OrderService) UpdateOrder(o order.Order) error {
	err := s.repo.Update(o)
	if err != nil {
		return err
	}
	_ = s.cache.Delete(o.ID) // сбрасываем кэш
	return nil
}
