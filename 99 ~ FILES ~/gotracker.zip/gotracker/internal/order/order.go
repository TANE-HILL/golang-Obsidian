package order

import "errors"

var ErrOrderNotFound = errors.New("order not found")

type Order struct {
	ID          int
	Customer    string
	Address     string
	IsDelivered bool
}

func (o *Order) MarkDelivered() {
	o.IsDelivered = true
}
