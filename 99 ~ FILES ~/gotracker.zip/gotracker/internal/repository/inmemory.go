package repository

import (
	"gotracker/internal/order"
	"sync"
)

type InMemoryOrderRepo struct {
	Orders map[int]order.Order
	mu     sync.Mutex
}

func NewInMemoryOrderRepo() *InMemoryOrderRepo {
	return &InMemoryOrderRepo{
		Orders: make(map[int]order.Order),
	}
}

func (repo *InMemoryOrderRepo) Add(order order.Order) error {
	defer repo.mu.Unlock()
	repo.mu.Lock()
	repo.Orders[order.ID] = order
	return nil
}

func (repo *InMemoryOrderRepo) GetByID(id int) (order.Order, error) {
	defer repo.mu.Unlock()
	repo.mu.Lock()
	value, ok := repo.Orders[id]
	if !ok {
		return value, order.ErrOrderNotFound
	}
	return value, nil
}

func (repo *InMemoryOrderRepo) Update(o order.Order) error {
	defer repo.mu.Unlock()
	repo.mu.Lock()
	if _, ok := repo.Orders[o.ID]; !ok {
		return order.ErrOrderNotFound
	}
	repo.Orders[o.ID] = o
	return nil
}

func (repo *InMemoryOrderRepo) GetAll() []order.Order {
	defer repo.mu.Unlock()
	repo.mu.Lock()
	orders := make([]order.Order, 0, len(repo.Orders))
	for _, o := range repo.Orders {
		orders = append(orders, o)
	}
	return orders
}
