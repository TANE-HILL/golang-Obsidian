package main

import (
	"database/sql"
	"fmt"
	"gotracker/internal/cache"
	apphttp "gotracker/internal/http"
	"gotracker/internal/queue"
	"gotracker/internal/repository"
	"gotracker/internal/service"
	"log"
	"net/http"
	"os"
	"strconv"

	"github.com/joho/godotenv"
	_ "github.com/lib/pq"
)

func main() {

	if err := godotenv.Load(); err != nil {
		log.Println("Файл .env не найден, используем переменные окружения")
	}
	dsn := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=disable",
		os.Getenv("DB_HOST"),
		os.Getenv("DB_PORT"),
		os.Getenv("DB_USER"),
		os.Getenv("DB_PASSWORD"),
		os.Getenv("DB_NAME"),
	)
	db, err := sql.Open("postgres", dsn)
	if err != nil {
		log.Fatal(err)
	}
	if err := db.Ping(); err != nil {
		log.Fatal("Не удалось подключиться к БД:", err)
	}

	cacheTTL, _ := strconv.Atoi(os.Getenv("REDIS_TTL"))
	redisCache := cache.NewRedisCache(os.Getenv("REDIS_ADDR"), cacheTTL)

	queue.StartConsumer()

	repo := repository.NewPostgresOrderRepo(db)
	svc := service.NewOrderService(repo, redisCache)
	handler := apphttp.NewHandler(svc, db, redisCache)

	log.Println("Сервер запущен на http://localhost:8080")
	err = http.ListenAndServe(":8080", handler)
	if err != nil {
		log.Fatal(err)
	}
}
