-- Добавление нового заказа
INSERT INTO orders (id, customer, address)
VALUES (1, 'Александр Авдеев', 'Сити-17');

-- Получение всех заказов
SELECT * FROM orders;

-- Обновление статуса заказа
UPDATE orders SET is_delivered = TRUE WHERE id = 1;

-- Удаление заказа
DELETE FROM orders WHERE id = 1;

-- Агрегация, количество (не)доставленных заказов
SELECT is_delivered, COUNT(*) AS order_count FROM orders
GROUP BY is_delivered;